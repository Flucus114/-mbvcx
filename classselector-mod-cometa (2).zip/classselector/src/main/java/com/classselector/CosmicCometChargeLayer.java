package com.classselector;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.util.Mth;

/**
 * Desenha, na mão do Soberano que vai arremessar, o núcleo do cometa crescendo durante a preparação.
 * Some no instante em que o cometa de verdade é lançado.
 */
public class CosmicCometChargeLayer extends RenderLayer<CosmicBoss, CosmicBossModel> {
    /** Tamanho final do orbe de carga em relação ao núcleo do cometa lançado. */
    private static final float MAX_SCALE = 1.2F;

    public CosmicCometChargeLayer(RenderLayerParent<CosmicBoss, CosmicBossModel> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, CosmicBoss e, float limbSwing,
                       float limbSwingAmount, float partialTick, float age, float yaw, float pitch) {
        CosmicBossModel model = getParentModel();
        for (int s = 0; s < 2; s++) {
            float charge = model.getChargeSize(s);
            if (charge < 0.03F) continue;
            ps.pushPose();
            model.translateToHand(s, ps);
            // à frente da ponta dos dedos (os dedos apontam para +Y local da mão)
            ps.translate(0.0F, 10.0F / 16.0F, 0.0F);
            ps.mulPose(Axis.YP.rotationDegrees(age * 14.0F + s * 90.0F));
            ps.mulPose(Axis.XP.rotationDegrees(age * 9.0F));
            float sc = MAX_SCALE * charge * (1.0F + 0.08F * Mth.sin(age * 1.1F));
            ps.scale(sc, sc, sc);
            VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(CosmicCometRenderer.TEXTURE));
            CosmicCometRenderer.drawCubes(ps.last(), vc, 0, CosmicCometModel.HEAD_COUNT);
            ps.popPose();
        }
    }
}
