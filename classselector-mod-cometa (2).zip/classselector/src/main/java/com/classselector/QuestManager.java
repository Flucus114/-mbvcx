package com.classselector;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Lógica de servidor das quests. */
public class QuestManager {
    /** Jogadores com progresso novo, a enviar em lote (evita um pacote por bloco minerado). */
    public static final Set<UUID> pending = new HashSet<>();

    /** Classe escolhida pelo jogador ("" se ainda não escolheu). */
    public static String classOf(ServerPlayer p) {
        return p.getPersistentData().getString(ClassSelectorMod.KEY);
    }

    /** A aba é liberada para a classe do jogador? (aba sem filtro = todos) */
    public static boolean tabAllows(QuestTabDef t, ServerPlayer p) {
        return t == null || t.classId.isEmpty() || t.classId.equals(classOf(p));
    }

    /** O filtro de classe (\"\" = todas) permite a classe deste jogador? */
    public static boolean classAllows(String classId, ServerPlayer p) {
        return classId.isEmpty() || classId.equals(classOf(p));
    }

    /** Aba E quest precisam permitir a classe do jogador. */
    public static boolean questAllows(QuestData qd, QuestDef q, ServerPlayer p) {
        return classAllows(q.classId, p) && tabAllows(qd.tabs.get(q.tab), p);
    }

    public static boolean unlocked(QuestData qd, PlayerQuestData.PQ pq, QuestDef q) {
        return q.parent.isEmpty() || !qd.quests.containsKey(q.parent) || pq.done.contains(q.parent);
    }

    /** Soma progresso a todas as quests ATIVAS (desbloqueadas) do tipo/alvo. */
    public static void add(ServerPlayer p, QuestType type, String target, int n) {
        QuestData qd = QuestData.get(p.server);
        PlayerQuestData pd = PlayerQuestData.get(p.server);
        PlayerQuestData.PQ pq = pd.of(p.getUUID());
        boolean changed = false;
        for (QuestDef q : new ArrayList<>(qd.quests.values())) {
            if (q.type != type || pq.done.contains(q.id) || !unlocked(qd, pq, q) || !questAllows(qd, q, p)) continue;
            if (type.needsTarget() && !q.target.equals(target)) continue;
            int v = Math.min(q.amount, pq.progress.getOrDefault(q.id, 0) + n);
            pq.progress.put(q.id, v);
            changed = true;
            if (v >= q.amount) complete(p, pq, q);
        }
        if (changed) {
            pd.setDirty();
            pending.add(p.getUUID());
        }
    }

    /** Quests de "obter item": contam o que o jogador tem no inventário. */
    public static void checkItems(ServerPlayer p) {
        QuestData qd = QuestData.get(p.server);
        PlayerQuestData pd = PlayerQuestData.get(p.server);
        PlayerQuestData.PQ pq = pd.of(p.getUUID());
        boolean changed = false;
        for (QuestDef q : new ArrayList<>(qd.quests.values())) {
            if (q.type != QuestType.ITEM || pq.done.contains(q.id) || !unlocked(qd, pq, q) || !questAllows(qd, q, p)) continue;
            int count = 0;
            for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
                ItemStack s = p.getInventory().getItem(i);
                if (s.isEmpty()) continue;
                var key = ForgeRegistries.ITEMS.getKey(s.getItem());
                if (key != null && key.toString().equals(q.target)) count += s.getCount();
            }
            int v = Math.min(q.amount, count);
            if (v != pq.progress.getOrDefault(q.id, 0)) {
                pq.progress.put(q.id, v);
                changed = true;
            }
            if (v >= q.amount) complete(p, pq, q);
        }
        if (changed) {
            pd.setDirty();
            pending.add(p.getUUID());
        }
    }

    private static void complete(ServerPlayer p, PlayerQuestData.PQ pq, QuestDef q) {
        pq.done.add(q.id);
        pq.progress.put(q.id, q.amount);
        for (ItemStack s : q.rewards) {
            ItemStack c = s.copy();
            if (!p.getInventory().add(c)) p.drop(c, false);
        }
        if (q.xp > 0) p.giveExperienceLevels(q.xp);
        p.sendSystemMessage(Component.literal("Missão concluída: ").withStyle(ChatFormatting.GREEN)
                .append(Component.literal(q.name).withStyle(ChatFormatting.GOLD)));
        p.playNotifySound(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 1f, 1f);
        PlayerQuestData.get(p.server).setDirty();
        pending.add(p.getUUID());
    }

    public static void sync(ServerPlayer p, boolean open) {
        QuestData qd = QuestData.get(p.server);
        PlayerQuestData.PQ pq = PlayerQuestData.get(p.server).of(p.getUUID());
        CompoundTag t = new CompoundTag();
        boolean op = p.hasPermissions(2); // OP vê todas as abas para poder editar
        Set<String> tabsSent = new HashSet<>();
        ListTag tl = new ListTag();
        for (QuestTabDef x : qd.tabs.values()) {
            if (!op && !tabAllows(x, p)) continue;
            tl.add(x.save());
            tabsSent.add(x.id);
        }
        t.put("tabs", tl);
        Set<String> questsSent = new HashSet<>();
        ListTag ql = new ListTag();
        for (QuestDef x : qd.quests.values()) {
            if (!tabsSent.contains(x.tab)) continue;
            if (!op && !classAllows(x.classId, p)) continue; // quest de outra classe nem é enviada
            ql.add(x.save());
            questsSent.add(x.id);
        }
        t.put("quests", ql);
        CompoundTag pr = new CompoundTag();
        for (Map.Entry<String, Integer> e : pq.progress.entrySet())
            if (questsSent.contains(e.getKey())) pr.putInt(e.getKey(), e.getValue());
        t.put("progress", pr);
        ListTag dl = new ListTag();
        for (String s : pq.done) if (questsSent.contains(s)) dl.add(StringTag.valueOf(s));
        t.put("done", dl);
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new QuestNet.QSync(open, t));
    }

    public static void syncAll(MinecraftServer s) {
        for (ServerPlayer p : s.getPlayerList().getPlayers()) sync(p, false);
    }
}
