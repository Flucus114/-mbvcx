package com.classselector;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;

/** Baú onde o OP coloca os itens que o jogador recebe ao desbloquear a habilidade. */
public class SkillRewardMenu extends ChestMenu {
    private final String skillId;
    private final SimpleContainer box;

    public static void open(ServerPlayer p, SkillDef def) {
        SimpleContainer box = new SimpleContainer(27);
        for (int i = 0; i < def.rewards.size() && i < 27; i++) box.setItem(i, def.rewards.get(i).copy());
        p.openMenu(new SimpleMenuProvider(
                (id, inv, pl) -> new SkillRewardMenu(id, inv, box, def.id),
                Component.literal("Itens: " + def.name)));
    }

    private SkillRewardMenu(int id, Inventory inv, SimpleContainer box, String skillId) {
        super(MenuType.GENERIC_9x3, id, inv, box, 3);
        this.box = box;
        this.skillId = skillId;
    }

    @Override
    public void removed(Player pl) {
        super.removed(pl);
        if (!(pl instanceof ServerPlayer sp)) return;
        SkillData data = SkillData.get(sp.server);
        SkillDef s = data.skills.get(skillId);
        if (s == null) return;
        s.rewards.clear();
        for (int i = 0; i < box.getContainerSize(); i++) {
            ItemStack st = box.getItem(i);
            if (!st.isEmpty()) s.rewards.add(st.copy());
        }
        data.setDirty();
        SkillManager.syncAll(sp.server);
    }
}
