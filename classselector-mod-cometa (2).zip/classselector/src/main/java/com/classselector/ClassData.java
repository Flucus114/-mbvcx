package com.classselector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Guarda as classes no mundo (sobrevive a reinícios do servidor). */
public class ClassData extends SavedData {
    public final Map<String, ClassDef> classes = new LinkedHashMap<>();

    public static ClassData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(ClassData::load, ClassData::createDefault, "classselector_classes");
    }

    private static ClassData createDefault() {
        ClassData d = new ClassData();

        ClassDef w = new ClassDef();
        w.id = "guerreiro";
        w.name = "Guerreiro";
        w.description = "Especialista em combate corpo a corpo, com alta resistência e grande poder ofensivo.";
        w.icon = "minecraft:iron_helmet";
        w.abilities.addAll(List.of("Força aumentada", "Resistência elevada", "Golpe poderoso"));
        w.items.add(new ItemStack(Items.IRON_SWORD));
        w.items.add(new ItemStack(Items.SHIELD));
        w.items.add(new ItemStack(Items.IRON_CHESTPLATE));
        d.classes.put(w.id, w);

        ClassDef a = new ClassDef();
        a.id = "arqueiro";
        a.name = "Arqueiro";
        a.description = "Atira de longe com precisão e se move com agilidade.";
        a.icon = "minecraft:bow";
        a.abilities.addAll(List.of("Mira precisa", "Movimento ágil"));
        a.items.add(new ItemStack(Items.BOW));
        a.items.add(new ItemStack(Items.ARROW, 32));
        d.classes.put(a.id, a);

        d.setDirty();
        return d;
    }

    public static ClassData load(CompoundTag tag) {
        ClassData d = new ClassData();
        for (Tag t : tag.getList("classes", Tag.TAG_COMPOUND)) {
            ClassDef c = ClassDef.load((CompoundTag) t);
            if (!c.id.isEmpty()) d.classes.put(c.id, c);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag l = new ListTag();
        for (ClassDef c : classes.values()) l.add(c.save());
        tag.put("classes", l);
        return tag;
    }
}
