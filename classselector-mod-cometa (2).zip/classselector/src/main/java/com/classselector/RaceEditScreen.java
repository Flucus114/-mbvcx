package com.classselector;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

/** Editor de raça (só para OPs): nome, descrição, ícone e todos os bônus. */
public class RaceEditScreen extends Screen {
    private final Screen parent;
    private final RaceDef orig;
    private EditBox id, name, desc, icon, mana, armor, damage, speed, mining, enchant;

    public RaceEditScreen(Screen parent, RaceDef orig) {
        super(Component.literal(orig == null ? "Nova raça" : "Editar raça"));
        this.parent = parent;
        this.orig = orig;
    }

    private EditBox text(int x, int y, String val) {
        EditBox b = new EditBox(font, x, y, 150, 18, Component.empty());
        b.setMaxLength(256);
        b.setValue(val);
        addRenderableWidget(b);
        return b;
    }

    private EditBox num(int x, int y, double val) {
        EditBox b = new EditBox(font, x, y, 150, 18, Component.empty());
        b.setMaxLength(10);
        b.setFilter(s -> s.isEmpty() || s.matches("-?\\d*[.,]?\\d*"));
        b.setValue(RaceDef.fmt(val));
        addRenderableWidget(b);
        return b;
    }

    private static double parse(EditBox b) {
        try { return Double.parseDouble(b.getValue().trim().replace(',', '.')); }
        catch (Exception e) { return 0; }
    }

    private int y0() { return Math.max(16, height / 2 - 108); }

    @Override
    protected void init() {
        int cx = width / 2, lx = cx - 155, rx = cx + 5, y = y0(), s = 32;

        id = text(lx, y + 11, orig == null ? "" : orig.id);
        id.setEditable(orig == null);
        name = text(lx, y + 11 + s, orig == null ? "" : orig.name);
        desc = text(lx, y + 11 + 2 * s, orig == null ? "" : orig.description);
        icon = text(lx, y + 11 + 3 * s, orig == null ? "minecraft:emerald" : orig.icon);
        addRenderableWidget(Button.builder(Component.literal("Ícone = item na mão"), b -> {
            ItemStack held = minecraft.player.getMainHandItem();
            if (!held.isEmpty()) icon.setValue(ForgeRegistries.ITEMS.getKey(held.getItem()).toString());
        }).bounds(lx, y + 11 + 4 * s, 150, 20).build());

        mana = num(rx, y + 11, orig == null ? 0 : orig.mana);
        armor = num(rx, y + 11 + s, orig == null ? 0 : orig.armor);
        damage = num(rx, y + 11 + 2 * s, orig == null ? 0 : orig.damage);
        speed = num(rx, y + 11 + 3 * s, orig == null ? 0 : orig.speedPct);
        mining = num(rx, y + 11 + 4 * s, orig == null ? 0 : orig.miningPct);
        enchant = num(rx, y + 11 + 5 * s, orig == null ? 0 : orig.enchant);

        int by = y + 11 + 5 * s + 28;
        addRenderableWidget(Button.builder(Component.literal("Salvar"), b -> { if (save()) onClose(); })
                .bounds(lx, by, 100, 20).build());
        Button del = addRenderableWidget(Button.builder(Component.literal("Excluir"), b -> {
            Net.CH.sendToServer(new Net.DeleteRace(orig.id));
            onClose();
        }).bounds(lx + 105, by, 100, 20).build());
        del.active = orig != null;
        addRenderableWidget(Button.builder(Component.literal("Voltar"), b -> onClose())
                .bounds(lx + 210, by, 100, 20).build());
    }

    private boolean save() {
        String rid = ClassDef.sanitize(id.getValue());
        if (rid.isEmpty() || name.getValue().isBlank()) return false;
        RaceDef r = new RaceDef();
        r.id = rid;
        r.name = name.getValue().trim();
        r.description = desc.getValue().trim();
        r.icon = icon.getValue().trim();
        r.mana = parse(mana);
        r.armor = parse(armor);
        r.damage = parse(damage);
        r.speedPct = parse(speed);
        r.miningPct = parse(mining);
        r.enchant = (int) Math.round(parse(enchant));
        Net.CH.sendToServer(new Net.SaveRace(r.save()));
        return true;
    }

    @Override
    public void onClose() { minecraft.setScreen(parent); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int cx = width / 2, lx = cx - 155, rx = cx + 5, y = y0(), s = 32, c = 0xFFAAAAAA;
        g.drawCenteredString(font, title, cx, y - 12 < 2 ? 2 : y - 12, 0xFFFFFF);
        g.drawString(font, "ID (a-z, 0-9, _)", lx, y, c, false);
        g.drawString(font, "Nome", lx, y + s, c, false);
        g.drawString(font, "Descrição", lx, y + 2 * s, c, false);
        g.drawString(font, "Ícone (id do item)", lx, y + 3 * s, c, false);
        g.drawString(font, "Mana máx. (Iron's Spells)", rx, y, c, false);
        g.drawString(font, "Defesa (armadura)", rx, y + s, c, false);
        g.drawString(font, "Dano corpo a corpo", rx, y + 2 * s, c, false);
        g.drawString(font, "Velocidade (%)", rx, y + 3 * s, c, false);
        g.drawString(font, "Vel. de mineração (%)", rx, y + 4 * s, c, false);
        g.drawString(font, "Poder de encantamento (níveis)", rx, y + 5 * s, c, false);
        super.render(g, mx, my, pt);
    }
}
